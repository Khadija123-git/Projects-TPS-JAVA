package MonCode;

public interface Gestion {
      void ajouter();
      void supprimer();
      void afficher();
      void associer();
      void rechercher();

}
