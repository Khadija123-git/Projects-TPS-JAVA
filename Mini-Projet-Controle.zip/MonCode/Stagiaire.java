package MonCode;

public class Stagiaire extends Personne {
    private String niveau_etude ;

    public Stagiaire (String nom , String prenom , String niveau_etude){
        super(nom,prenom);
        this.niveau_etude = niveau_etude;
    }
    public String getniveau_etude (){
        return niveau_etude ;
    }
    @Override
    public void afficher() {
        System.out.println("Le nom complet du stagiaire est " + getNom() + " " + getPrenom() + ", et son niveau d'etude est :" + getniveau_etude());

    }
}
