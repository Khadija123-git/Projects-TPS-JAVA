package MonCode;

import java.util.ArrayList;

public class Stage {
    private String titre ;
    private int duree ;
    private ArrayList<Stagiaire> stagiaires ;

    public Stage(String titre , int duree ){
        this.titre = titre ;
        this.duree = duree ;
        this.stagiaires = new ArrayList<>();
    }
    public String getTitre(){
        return titre ;
    }
    public void ajouter_stagiaire(Stagiaire stagiaire){
        if (!stagiaires.contains(stagiaire)){
            stagiaires.add(stagiaire);
            System.out.println("Le stagiaire est ajouté avec succé.");
        }else {
            System.out.println("Le stagiaire est deja ajouté á ce stage .");
        }
    }
    public void afficher_info(){
        System.out.println("Le titre du stage est :" + titre + ", sa duree est :" + duree );
        System.out.println("Les stagiaires associés sont :");
        for (Stagiaire stagiaire : stagiaires){
            System.out.println (" " + stagiaire.getNom()+ " " + stagiaire.getPrenom() + " " + stagiaire.getniveau_etude());
        }
    }


}
