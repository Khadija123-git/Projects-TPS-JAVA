package MonCode;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Gestionnaire gestionnaire = new Gestionnaire();
        Scanner scanner = new Scanner(System.in);
        int choix;

        do {
            System.out.println("      &&MonCode.Gestion des stages&&     :");
            System.out.println("\nMenu :");
            System.out.println("1-Ajouter");
            System.out.println("2-Supprimer  ");
            System.out.println("3-Afficher");
            System.out.println("4- Associer un stagiaire à un stage");
            System.out.println("5-Rechercher un stagiaire");
            System.out.println("6-Quitter");
            System.out.println("Entrez votre choix :");
            choix = scanner.nextInt();
            scanner.nextLine();


            switch (choix) {
                case 1:
                    gestionnaire.ajouter();
                    break;
                case 2:
                    gestionnaire.supprimer();
                    break;
                case 3:
                    gestionnaire.afficher();
                    break;
                case 4 :
                    gestionnaire.associer();

                    break;
                case 5 :
                    gestionnaire.rechercher();
                    break;
                case 6:
                    System.out.println("Merci pour utiliser cette application ");
                    break;
                default:
                    System.out.println("choix inavlide ");

            }
        } while (choix != 6);
    }
}