package MonCode;

import java.util.ArrayList;
import java.util.Scanner;

public class Gestionnaire implements Gestion {
    private ArrayList<Stagiaire> stagiaires;
    private ArrayList<Stage> stages;
    private Scanner scanner;


    public Gestionnaire() {
        this.stagiaires = new ArrayList<>();
        this.stages = new ArrayList<>();
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void ajouter() {
        System.out.println("1- Ajouter un stagiaire :");
        System.out.println("2- Ajouter un stage ");
        int choix = scanner.nextInt();
        scanner.nextLine();

        if (choix == 1) {
            // Pour ajouter un stagiaire
            System.out.print("Entrez le nom du stagiaire :");
            String Nom = scanner.nextLine();
            System.out.print("Entrez le prenom du stagiaire :");
            String Prenom = scanner.nextLine();
            System.out.print("Entrez le niveua d'etude :");
            String niveau_etude = scanner.nextLine();
            Stagiaire stagiaire = new Stagiaire(Nom, Prenom, niveau_etude);
            if (!stagiaires.contains(stagiaire)) {
                // on verifie si le stagiaire est dans le stage ou pas
                stagiaires.add(stagiaire);
                System.out.println("Le stagiaire est ajouté avec succé.");
            } else {
                System.out.println("Le stagiaire est deja ajouté á ce stage .");
            }
        } else if (choix == 2) {
            //Pour ajouter un stage
            System.out.println("Entrez le titre du stage :");
            String titre = scanner.nextLine();
            System.out.println("Entrez la durée du stage :");
            int duree =scanner.nextInt();
            scanner.nextLine();
            Stage stage = new Stage(titre, duree);
            stages.add(stage);
            System.out.println("MonCode.Stage ajouté avec succé .");
        }
    }

    @Override
    public void supprimer() {
        System.out.println("1-supprimer un stagiaire :");
        System.out.println("2-supprimer un stage :");
        int choix = scanner.nextInt();
        scanner.nextLine();

        if (choix == 1) {
            //Pour supprimer un stagiaire
            System.out.print("Entrez le nom du stagiaire qui vous vouley la supprimer :");
            String Nom = scanner.nextLine();
            boolean supprimer = false;
            // Pour verifier si le satgiaire mentionné est trouvé
            for (int i = 0; i < stagiaires.size(); i++) {
                if (stagiaires.get(i).getNom().equalsIgnoreCase(Nom)){
                    // comparer le nom de chaque stagiaire dans la liste avec le stagiaire mentionné
                    stagiaires.remove(i);
                    supprimer = true;
                    System.out.println("Le stagiaire est supprimé .");
                    break;
                }
            }

            if (!supprimer) {
                System.out.println("Le stagiaire ne se trouve pas dans la liste:");
            }
        } else if (choix == 2) {
            // Pour supprimer un stage
            System.out.print("Entrez le titre du stage que vous voulez supprimer :");
            String titre = scanner.nextLine();
            boolean supprimer = false;
            for (int i = 0; i < stages.size(); i++) {
                if (stages.get(i).getTitre().equalsIgnoreCase(titre)) {
                    stages.remove(i);
                    supprimer = true;
                    System.out.println("MonCode.Stage supprime avec succé .");
                    break;
                }
            }
            if (!supprimer) {
                System.out.println("MonCode.Stage non trouvé");
            }
        }
    }

    @Override
    public void afficher() {
        System.out.println("1-Afficher tous les stagiaires :");
        System.out.println("2-Afficher tous les stages :");
        int choix = scanner.nextInt();
        scanner.nextLine();

        if (choix == 1) {
            //Pour afficher tous les stagiaires

            System.out.println("Tous les stagiaires :");
            for (Stagiaire stagiaire : stagiaires) {
                stagiaire.afficher();
            }
        } else if (choix == 2) {
            //Pour afficher tous les stages avec leurs stages associés
            System.out.println("Tous les stages :");
            for (Stage stage : stages) {
                stage.afficher_info();
            }
        }
    }
    @Override
    public void associer(){
        System.out.print("Entrez le nom du stagiaire que vous voulez associer :");
        String nom = scanner.nextLine();
        System.out.print("Entrez le titre du stage :");
        String Titre = scanner.nextLine();

        Stagiaire stagiaire = null ;
        // Pour indiquer la presence ou l'abscence du stagiaire
        for (Stagiaire x : stagiaires){
            if (x.getNom().equalsIgnoreCase(nom )){
                stagiaire = x ;
                break ;
            }
        }
        Stage stage = null ;
        //Pour indiquer la presence ou l'abscence du stage
        for(Stage y : stages ){
            if (y.getTitre().equalsIgnoreCase(Titre)){
                stage = y ;
                break ;
            }
        }
        if (stagiaire!=null && stage!=null){
            stage.ajouter_stagiaire(stagiaire);
        } else {
            System.out.println("erreur ");
        }
    }
    @Override
    public void rechercher(){
        System.out.println("1- Recherche par le nom  ");
        System.out.println("2- Recherche avec le niveau d'etude ");
        int choix = scanner.nextInt();
        scanner.nextLine();

        if (choix==1) {

            System.out.print("Entrez le nom du stagiaire que vous voulez rechercher :");
            String nom = scanner.nextLine();
            for (Stagiaire stagiaire : stagiaires) {
                if (stagiaire.getNom().equalsIgnoreCase(nom)) {
                    stagiaire.afficher();
                    return;
                }
            }
        } else if (choix == 2){
            System.out.println("Entrez le niveau d'etude du stagiaire que vous voulez rechercher :");
            String niveau = scanner.nextLine();
            for (Stagiaire stagiaire : stagiaires){
                if(stagiaire.getniveau_etude().equalsIgnoreCase(niveau)) {
                    stagiaire.afficher();
                    return;
                }
            }

        }
    }
}




