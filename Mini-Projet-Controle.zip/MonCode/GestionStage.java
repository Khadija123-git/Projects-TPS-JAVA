package MonCode;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GestionStage extends JFrame {
    private ArrayList<Stagiaire> listestagiaire;
    private JTextField nomField, prenomField, niveauEtudeField;
    private JTextArea affichageStagiaires;

    public GestionStage() {
        listestagiaire= new ArrayList<>();

        setTitle("MonCode.Gestion des Stagiaires");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panelSaisie = new JPanel();
        panelSaisie.setLayout(new GridLayout(4, 2));

        panelSaisie.add(new JLabel("Nom :"));
        nomField = new JTextField();
        panelSaisie.add(nomField);

        panelSaisie.add(new JLabel("Prénom :"));
        prenomField = new JTextField();
        panelSaisie.add(prenomField);

        panelSaisie.add(new JLabel("Niveau d'étude :"));
        niveauEtudeField = new JTextField();
        panelSaisie.add(niveauEtudeField);

        JButton ajouterButton = new JButton("Ajouter");
        panelSaisie.add(ajouterButton);

        ajouterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nom = nomField.getText();
                String prenom = prenomField.getText();
                String niveauEtude = niveauEtudeField.getText();

                if (!nom.isEmpty() && !prenom.isEmpty() && !niveauEtude.isEmpty()) {
                    Stagiaire stagiaire = new Stagiaire(nom, prenom, niveauEtude);
                    listestagiaire.add(stagiaire);
                    JOptionPane.showMessageDialog(null, "MonCode.Stagiaire ajouté avec succès !");
                    nomField.setText("");
                    prenomField.setText("");
                    niveauEtudeField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs !");
                }
            }
        });


        JPanel panelAffichage = new JPanel();
        panelAffichage.setLayout(new BorderLayout());

        affichageStagiaires = new JTextArea();
        affichageStagiaires.setEditable(false);
        panelAffichage.add(new JScrollPane(affichageStagiaires), BorderLayout.CENTER);

        JButton afficherButton = new JButton("Afficher Stagiaires");
        panelAffichage.add(afficherButton, BorderLayout.SOUTH);


        afficherButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                affichageStagiaires.setText("");
                for (Stagiaire stagiaire :listestagiaire) {
                    affichageStagiaires.append(stagiaire.toString() + "\n");
                }
            }
        });


        add(panelSaisie, BorderLayout.NORTH);
        add(panelAffichage, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GestionStage().setVisible(true);
        });
    }
}


